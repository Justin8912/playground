def handler(request):
    print("Hello World")
    return {}
